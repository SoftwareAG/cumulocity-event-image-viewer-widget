import { MatDialogRef } from '@angular/material';
import { GpS3ImageViewerService } from './gp-s3-image-viewer.service';
import { DomSanitizer } from '@angular/platform-browser';
export interface DialogData {
    eventData: any;
}
export declare class CarouselImageViewer {
    dialogRef: MatDialogRef<CarouselImageViewer>;
    imageViewrService: GpS3ImageViewerService;
    _DomSanitizationService: DomSanitizer;
    data: DialogData;
    url: string;
    noWrapSlides: boolean;
    constructor(dialogRef: MatDialogRef<CarouselImageViewer>, imageViewrService: GpS3ImageViewerService, _DomSanitizationService: DomSanitizer, data: DialogData);
    onNoClick(): void;
    errorInloading(event: any): void;
    carouselChanged(event: any): void;
}

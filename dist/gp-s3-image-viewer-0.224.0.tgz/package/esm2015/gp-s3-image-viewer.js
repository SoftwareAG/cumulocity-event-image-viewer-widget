/**
 * @fileoverview added by tsickle
 * Generated from: gp-s3-image-viewer.ts
 * @suppress {checkTypes,constantProperty,extraRequire,missingOverride,missingReturn,unusedPrivateMembers,uselessCode} checked by tsc
 */
/**
 * Generated bundle index. Do not edit.
 */
export { GpS3ImageViewerService, GpS3ImageViewerComponent, ImageViewerDialog, GpS3ImageViewerModule } from './public_api';
export { CarouselImageViewer as ɵb } from './lib/carousel-image-viewer';
export { GpS3ImageViewerConfigComponent as ɵa } from './lib/gp-s3-image-viewer-config/gp-s3-image-viewer-config.component';
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3AtczMtaW1hZ2Utdmlld2VyLmpzIiwic291cmNlUm9vdCI6Im5nOi8vZ3AtczMtaW1hZ2Utdmlld2VyLyIsInNvdXJjZXMiOlsiZ3AtczMtaW1hZ2Utdmlld2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBSUEsMkdBQWMsY0FBYyxDQUFDO0FBRTdCLE9BQU8sRUFBQyxtQkFBbUIsSUFBSSxFQUFFLEVBQUMsTUFBTSw2QkFBNkIsQ0FBQztBQUN0RSxPQUFPLEVBQUMsOEJBQThCLElBQUksRUFBRSxFQUFDLE1BQU0scUVBQXFFLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIEdlbmVyYXRlZCBidW5kbGUgaW5kZXguIERvIG5vdCBlZGl0LlxuICovXG5cbmV4cG9ydCAqIGZyb20gJy4vcHVibGljX2FwaSc7XG5cbmV4cG9ydCB7Q2Fyb3VzZWxJbWFnZVZpZXdlciBhcyDJtWJ9IGZyb20gJy4vbGliL2Nhcm91c2VsLWltYWdlLXZpZXdlcic7XG5leHBvcnQge0dwUzNJbWFnZVZpZXdlckNvbmZpZ0NvbXBvbmVudCBhcyDJtWF9IGZyb20gJy4vbGliL2dwLXMzLWltYWdlLXZpZXdlci1jb25maWcvZ3AtczMtaW1hZ2Utdmlld2VyLWNvbmZpZy5jb21wb25lbnQnOyJdfQ==